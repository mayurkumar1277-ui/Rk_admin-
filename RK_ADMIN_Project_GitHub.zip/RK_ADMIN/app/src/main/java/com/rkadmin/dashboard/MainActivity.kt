package com.rkadmin.dashboard

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 18, 33)
    private val panel = Color.rgb(25, 33, 54)
    private val accent = Color.rgb(85, 133, 255)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("RK ADMIN", 27, Color.WHITE, true))
        page.addView(label("ADMIN CONTROL CENTER", 11, Color.LTGRAY, true).apply {
            letterSpacing = 0.16f
            setPadding(0, dp(3), 0, dp(20))
        })

        val welcome = card()
        welcome.addView(label("Welcome back, Admin", 19, Color.WHITE, true))
        welcome.addView(label("Your dashboard overview", 13, 0xFFB8C3D9.toInt(), false))
        page.addView(welcome)

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(statCard("USERS", "1,248", "Registered accounts"), weightParams())
        stats.addView(space(10))
        stats.addView(statCard("ACTIVE", "936", "Currently active"), weightParams())
        page.addView(stats)

        page.addView(sectionTitle("QUICK ACTIONS"))
        val actions = listOf(
            Triple("User Management", "View and manage user accounts", "Users"),
            Triple("App Settings", "Configure dashboard preferences", "Settings"),
            Triple("Activity Logs", "Review recent admin activity", "Logs"),
            Triple("Support Center", "Help and contact information", "Support")
        )
        actions.forEach { (title, subtitle, tag) ->
            val item = card()
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(label(title, 16, Color.WHITE, true))
            texts.addView(label(subtitle, 12, 0xFFB8C3D9.toInt(), false))
            line.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            val button = Button(this).apply {
                text = "OPEN"
                textSize = 10f
                setTextColor(Color.WHITE)
                background = rounded(accent, 18)
                setOnClickListener { showMessage("$tag section is a starter placeholder.") }
            }
            line.addView(button, LinearLayout.LayoutParams(dp(82), dp(42)))
            item.addView(line)
            page.addView(item)
        }

        page.addView(sectionTitle("SYSTEM STATUS"))
        val status = card()
        status.addView(statusRow("Dashboard", "Ready", true))
        status.addView(statusRow("User service", "Demo mode", false))
        status.addView(statusRow("Last updated", "Just now", false))
        page.addView(status)

        page.addView(label("RK ADMIN  •  VERSION 1.0", 10, 0xFF8290AA.toInt(), true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        })
    }

    private fun statCard(title: String, value: String, hint: String) = card().apply {
        addView(label(title, 10, 0xFF9EAFD0.toInt(), true))
        addView(label(value, 25, Color.WHITE, true).apply { setPadding(0, dp(5), 0, dp(2)) })
        addView(label(hint, 10, 0xFFB8C3D9.toInt(), false))
    }

    private fun statusRow(name: String, value: String, good: Boolean): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
            addView(label(name, 14, Color.WHITE, false), LinearLayout.LayoutParams(0, -2, 1f))
            addView(label("●  $value", 12, if (good) 0xFF69D6A2.toInt() else 0xFFFFC66D.toInt(), true))
        }
    }

    private fun sectionTitle(text: String) = label(text, 12, 0xFF9EAFD0.toInt(), true).apply {
        setPadding(2, dp(22), 0, dp(10))
        letterSpacing = 0.12f
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = rounded(panel, 18)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun space(width: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(width), 1)
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, -2, 1f).apply {
        bottomMargin = dp(2)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
