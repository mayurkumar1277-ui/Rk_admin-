# RK ADMIN

A simple original Android admin-dashboard starter project written in Kotlin.

## Build an APK on GitHub (phone-friendly)

1. Create a GitHub repository named `RK_ADMIN`.
2. Upload the **contents** of this project folder to the repository root (including the hidden `.github` folder).
3. Open the repository's **Actions** tab. The workflow `Build RK ADMIN APK` runs on pushes to `main`; you can also choose **Run workflow**.
4. When the run finishes successfully, open that run and download the artifact named `RK-ADMIN-debug-apk`.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The generated debug APK is for testing. It is not a Play Store release-signed APK.

## Notes

- Package: `com.rkadmin.dashboard`
- Minimum Android: API 23 (Android 6.0)
- The dashboard uses demo UI/actions only. It has no production backend, authentication, or user-management service.
- This project does not bypass or remove licensing, payment, anti-cheat, or other app protections.
